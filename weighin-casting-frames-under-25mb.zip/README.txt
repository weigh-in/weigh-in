135 animation frames
Format: JPEG (quality 94, full original 1280x800 dimensions)
The JPEG conversion keeps the archive under the 25 MB limit.
